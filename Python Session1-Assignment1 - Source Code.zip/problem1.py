a = input ("Enter a number ")

fact = 1
prn = ' '

for i in range(1,int(a)+1):
    print(i)
    fact = fact * i

prn = "Factorial of " + str(a) + " = " + str(fact)
print(prn)
