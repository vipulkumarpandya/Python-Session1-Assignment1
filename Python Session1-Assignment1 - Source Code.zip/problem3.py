fn = input ("Enter First name : ")
ln = input ("Enter Last name  : ")

print(fn[::-1] + " " + ln[::-1])
