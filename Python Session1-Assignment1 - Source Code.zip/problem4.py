diameter = 12

pi = 3.14159

v = (4/3) * pi * (diameter/2)**3

print(v)
